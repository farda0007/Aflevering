﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace TCPaflevering
{
    public class Client
    {
        private TcpClient _client;

        public Client(TcpClient client)
        {
            _client = client;
        }

        public void HandleClient()
        {
            using NetworkStream ns = _client.GetStream();
            using StreamReader reader = new StreamReader(ns);
            using StreamWriter writer = new StreamWriter(ns);

            bool keepListening = true;
            while (keepListening)
            {
                try
                {
                    string command = reader.ReadLine();
                    if (string.IsNullOrEmpty(command)) continue;

                    // Svar tilbage, at serveren venter på to tal
                    writer.WriteLine("Input numbers");
                    writer.Flush();

                    string numbers = reader.ReadLine();
                    //Opdel input i 2 tal, adskilt af mellemrum
                    string[] splitNumbers = numbers.Split(' ');

                    //Tjek om der skrives præcis 2 tal, hvis ikke, så skriv en fejlbesked
                    if (splitNumbers.Length != 2)
                    {
                        writer.WriteLine("Husk at angive to tal");
                        writer.Flush();
                        continue; //Videre til næste iteration
                    }

                    // Forsøg at konvertere de to input til heltal (int)
                    if (!int.TryParse(splitNumbers[0], out int number1) || !int.TryParse(splitNumbers[1], out int number2))
                    {
                        writer.Flush();
                        continue;
                    }

                    //Brug switch til at vælge den rigtige handling ud fra command
                    string result = command switch
                    {
                        "Random" => new Random().Next(number1, number2 + 1).ToString(),
                        "Add" => (number1 + number2).ToString(),
                        "Subtract" => (number1 - number2).ToString(),
                        _ => "Unknown command"
                    };

                    writer.WriteLine(result);
                    writer.Flush();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    keepListening = false;
                }
            }

            _client.Close();
        }
    }
}

