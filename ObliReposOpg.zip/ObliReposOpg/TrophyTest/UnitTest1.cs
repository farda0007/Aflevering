using ObliReposOpg;

namespace TrophyTest
{
    [TestClass]
    public class UnitTest1
    {
        private Trophy goodTrophy = new Trophy {Competition = "Fodbold", Year = 2000 };
        private Trophy nullComp = new Trophy {Competition = null, Year = 1991 };
        private Trophy shortComp = new Trophy {Competition = "bo", Year = 1995 };
        private Trophy badYear = new Trophy {Competition = "Ironman", Year = 1969 };

        [TestMethod]
        public void ToStringTest()
        {
            string str = goodTrophy.ToString();
            Assert.AreEqual("0 Fodbold 2000", goodTrophy.ToString());
        }
        [TestMethod]
        public void ValidateCompetitionTest()
        {
            goodTrophy.ValidateCompetition();
            Assert.ThrowsException<ArgumentNullException>(() => nullComp.ValidateCompetition());
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => shortComp.ValidateCompetition());
        }
        [TestMethod]
        public void TestYear()
        {
            goodTrophy.ValidateYear();
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => badYear.ValidateYear());
        }

        [TestMethod]
        public void ValidateTest()
        {
            goodTrophy.Validate();
            Assert.ThrowsException<ArgumentNullException>(() => nullComp.Validate());
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => shortComp.Validate());
            Assert.ThrowsException<ArgumentOutOfRangeException>(() => badYear.Validate());
        }

    }
}