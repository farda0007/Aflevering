﻿using ObliReposOpg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace TrophyTest
{
    [TestClass]
    public class RepoTest
    {

        private TrophiesRepository _repo;
        private Trophy _goodTrophy = new Trophy(6, "Ironman", 2000);

        private Trophy _shortComp = new Trophy(8, "bo", 1995);
 

        [TestInitialize]
        public void Init()
        {
            { _repo = new TrophiesRepository(); }
        }
        [TestMethod]
        public void GetTest()
        {
            IEnumerable<Trophy> trophies = _repo.Get();
            Assert.AreEqual(5, trophies.Count());
            Assert.AreEqual(trophies.First().Competition, "Ironman");

            IEnumerable<Trophy> sortedTrophies = _repo.Get(orderBy: "competition");
            Assert.AreEqual(sortedTrophies.First().Competition, "Fodbold");

            IEnumerable<Trophy> sortedTrophies2 = _repo.Get(orderBy: "year");
            Assert.AreEqual(sortedTrophies2.First().Competition, "Skateboard");
        }
        [TestMethod]
        public void GetByIdTest()
        {
            Assert.IsNotNull(_repo.GetById(1));
            Assert.IsNull(_repo.GetById(100));
        }
        [TestMethod]
        public void AddTest()
        {
            Trophy t = new() { Competition = "Test", Year = 2021 };
            Assert.AreEqual(6, _repo.Add(t).Id);
            Assert.AreEqual(6, _repo.Get().Count());

            Assert.ThrowsException<ArgumentOutOfRangeException>(() => _repo.Add(_shortComp));
        }
        [TestMethod]
        public void RemoveTest()
        {
            Assert.IsNull(_repo.RemoveTrophy(100));
            Assert.AreEqual(1, _repo.RemoveTrophy(1).Id);
            Assert.AreEqual(4, _repo.Get().Count());
        }
        [TestMethod]
        public void UpdateTest()
        {
            Assert.AreEqual(5, _repo.Get().Count());
            Trophy trophy = new() { Competition = "Test", Year = 2021 };
            Assert.IsNull(_repo.Update(50, trophy));
            Assert.AreEqual(1, _repo.Update(1, trophy)?.Id);
            Assert.AreEqual(5, _repo.Get().Count());

            Assert.ThrowsException<ArgumentOutOfRangeException>(() => _repo.Update(1, _shortComp));
        }

    }
}
