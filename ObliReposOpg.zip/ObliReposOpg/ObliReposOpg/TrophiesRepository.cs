﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace ObliReposOpg
{
    public class TrophiesRepository
    {
        public int _nextId = 6;

        private List<Trophy> _trophies = new()
        {
         new Trophy(1, "Ironman", 1998),
         new Trophy(2, "Fodbold", 2005),
         new Trophy(3, "Håndbold", 2010),
         new Trophy(4, "Poetry Slam", 2015),
         new Trophy(5, "Skateboard", 1990)
        };

        public TrophiesRepository()
        {
        }

        public Trophy? Add(Trophy trophy)
        {
            trophy.Validate();
            trophy.Id = _nextId++;
            _trophies.Add(trophy);
            return trophy;
        }
        public Trophy? GetById(int id)
        {
            return _trophies.Find(trophy => trophy.Id == id);
        }
        public IEnumerable<Trophy> Get(int? yearAfter = null, string? compIncludes = null, string? orderBy = null)
        {
            IEnumerable<Trophy> result = new List<Trophy>(_trophies);
            // Filtering
            if (yearAfter != null)
            {
                result = result.Where(m => m.Year > yearAfter);
            }
            if (compIncludes != null)
            {
                result = result.Where(m => m.Competition.Contains(compIncludes));
            }

            // Ordering aka. sorting
            if (orderBy != null)
            {
                orderBy = orderBy.ToLower();
                switch (orderBy)
                {
                    case "competition": // fall through to next case
                    case "competition_asc":
                        result = result.OrderBy(m => m.Competition);
                        break;
                    case "competition_desc":
                        result = result.OrderByDescending(m => m.Competition);
                        break;
                    case "year":
                    case "year_asc":
                        result = result.OrderBy(m => m.Year);
                        break;
                    case "year_desc":
                        result = result.OrderByDescending(m => m.Year);
                        break;
                    default:
                        break;
                }
            }
            return result;
        }
        public Trophy? RemoveTrophy(int id)
        {
            Trophy? trophy = GetById(id);
            if (trophy == null)
            {
                return null;
            }
            _trophies.Remove(trophy);
            return trophy;
        }

        public Trophy? Update(int id, Trophy trophy)
        {
            trophy.Validate();
            Trophy existingTrophy = GetById(id);
            if (existingTrophy == null)
            {
                return null;
            }
            existingTrophy.Competition = trophy.Competition;
            existingTrophy.Year = trophy.Year;
            return existingTrophy;
        }
    }
}
