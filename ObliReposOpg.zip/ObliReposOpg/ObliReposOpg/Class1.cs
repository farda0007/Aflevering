﻿namespace ObliReposOpg
{
    public class Class1
    {

    }
}
