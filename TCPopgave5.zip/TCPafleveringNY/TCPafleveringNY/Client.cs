﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text.Json;

namespace TCPafleveringNY
{
    public class Client
    {
        private TcpClient _client;

        public Client(TcpClient client)
        {
            _client = client;
        }

        public void HandleClient()
        {
            using NetworkStream ns = _client.GetStream();
            using StreamReader reader = new StreamReader(ns);
            using StreamWriter writer = new StreamWriter(ns);

            bool keepListening = true;
            while (keepListening)
            {
                try
                {
                    string command = reader.ReadLine();
                    if (string.IsNullOrEmpty(command)) continue;

                    //Opdeler kommandoen i parts. F.eks. hvis man skriver "add 10 20" vil parts være ["add", "10", "20"]
                    string[] parts = command.Split(' ');
                    // Konverterer den første del (metoden) til lowercase, som er kommandoen
                    string method = parts[0].ToLower();

                    //Tjekker om metode består af præcis 3 parts
                    if (parts.Length != 3 ||
                                            !int.TryParse(parts[1], out int tal1) || // Forsøg at konvertere den anden del (tal1) til et heltal
                                            !int.TryParse(parts[2], out int tal2))   // Forsøg at konvertere den tredje del (tal1) til et heltal
                    {
                        //Hvis input eller format er ugyldigt, aktiver "SendError"
                        SendError(writer, "Invalid input");
                        continue; // Spring til næste iteration af løkken for at vente på en ny kommando
                    }


                    // Tilføj kontrol for Random-metoden
                    if (method.Equals("Random", StringComparison.OrdinalIgnoreCase))
                    {
                        if (tal1 > tal2)
                        {
                            SendError(writer, "Tal1 skal være mindre end eller lig med Tal2 for Random.");
                            continue;
                        }
                    }

                    // udfør metoden og gem resultatet i en string = "result"
                    string result = method switch
                    {
                        "random" => new Random().Next(tal1, tal2 + 1).ToString(),
                        "add" => (tal1 + tal2).ToString(),
                        "subtract" => (tal1 - tal2).ToString(),
                        _ => "Unknown command"
                    };

                    // Send response tilbage i json format
                    var response = new JsonResponse
                    {
                        Method = method,
                        Tal1 = tal1,
                        Tal2 = tal2,
                        Result = result
                    };
                    writer.WriteLine(JsonSerializer.Serialize(response));
                    writer.Flush();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    keepListening = false;
                }
            }
            _client.Close();
        }

        //Sender error til klienten i JSON format. 
        //Opretter bliver oprettet et "JsonResponse" objekt med errorMessage.
        private void SendError(StreamWriter writer, string errorMessage)
        {
            var errorResponse = new JsonResponse { Result = errorMessage };
            writer.WriteLine(JsonSerializer.Serialize(errorResponse));
            writer.Flush();
        }
    }
}
